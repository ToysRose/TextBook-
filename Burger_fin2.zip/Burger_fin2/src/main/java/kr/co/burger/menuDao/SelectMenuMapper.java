package kr.co.burger.menuDao;

import kr.co.burger.domain.BurgerDate;

public interface SelectMenuMapper {

	BurgerDate burgerOneselect(int no);
}
