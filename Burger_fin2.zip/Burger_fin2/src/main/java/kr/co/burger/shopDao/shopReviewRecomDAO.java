package kr.co.burger.shopDao;

import kr.co.burger.domain.reviewDate;

public interface shopReviewRecomDAO {
	
	public int recom0(reviewDate param);
	public int recom1(reviewDate param);
	public int recom2(reviewDate param); 
	public int recom3(reviewDate param); 
}
