package kr.co.burger.start;

public class start {

	public static void main(String[] args) {
		new UI().service();
	}
}
