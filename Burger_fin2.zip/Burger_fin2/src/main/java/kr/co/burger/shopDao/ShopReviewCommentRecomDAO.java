package kr.co.burger.shopDao;

import kr.co.burger.domain.commentDate;

public interface ShopReviewCommentRecomDAO {
	public int recom0(commentDate param);
	public int recom1(commentDate param);
	public int recom2(commentDate param);
	public int recom3(commentDate param);
}
