package kr.co.burger.domain;

public class shopDate {

	private int code; 
	private String name;
	private String shop_address;
	private String phone_no;
	private int recom_cnt;
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShop_address() {
		return shop_address;
	}
	public void setShop_address(String shop_address) {
		this.shop_address = shop_address;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public int getRecom_cnt() {
		return recom_cnt;
	}
	public void setRecom_cnt(int recom_cnt) {
		this.recom_cnt = recom_cnt;
	}


	
}
