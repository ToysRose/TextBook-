package kr.co.burger.InterfaceA;

public abstract interface  BaseUI {

	public abstract void service();

}
