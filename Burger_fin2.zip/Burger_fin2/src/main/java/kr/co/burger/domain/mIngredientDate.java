package kr.co.burger.domain;

public class mIngredientDate {

	private int menuCode;
	private int ingreCode;
	
	public int getMenuCode() {
		return menuCode;
	}
	public void setMenuCode(int menuCode) {
		this.menuCode = menuCode;
	}
	public int getIngreCode() {
		return ingreCode;
	}
	public void setIngreCode(int ingreCode) {
		this.ingreCode = ingreCode;
	}
	
}
